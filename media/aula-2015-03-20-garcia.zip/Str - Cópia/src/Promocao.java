



public interface Promocao {
	double descontar();
}
