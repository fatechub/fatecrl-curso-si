
public class SemPromo implements Promocao{

	@Override
	public double descontar() {
		// TODO Auto-generated method stub
		return 1.;
	}

}
