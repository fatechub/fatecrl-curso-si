
public class Liquidacao implements Promocao{

	@Override
	public double descontar() {
		return 0.7;
	}


	
}
