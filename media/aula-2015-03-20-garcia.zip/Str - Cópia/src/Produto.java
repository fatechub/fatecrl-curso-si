import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;





public abstract class Produto {
	private String nome;
	private double preco;
	private Method promocao;
	
	public void setPromocao(Promocao promocao) throws NoSuchMethodException, SecurityException {
		Class<?> clazz = promocao.getClass();
		Method m = clazz.getDeclaredMethod("descontar", null);
		this.promocao = m;
		
	}

	public Produto(String nome, double preco) {
		this.nome = nome;
		this.preco = preco;
	}
	
	public double calcularPreco(Promocao promocao) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		double aux = (double) this.promocao.invoke(promocao, null);
		return aux*preco;
	}
	
	public String toString(){
		return "Produto: "+nome;
	}
	
}
