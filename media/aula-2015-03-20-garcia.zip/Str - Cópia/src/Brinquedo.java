
public final class Brinquedo extends Produto{

	public Brinquedo(String nome, double preco) {
		super(nome, preco);
	}



}
