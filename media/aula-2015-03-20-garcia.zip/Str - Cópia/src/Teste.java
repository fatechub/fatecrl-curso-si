import java.lang.reflect.InvocationTargetException;


public class Teste {

	public static void main(String[] args) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException {
		Brinquedo b = new Brinquedo("Monster High",60);
		Brinquedo b1 = new Brinquedo("Barbie Esquiadora",60);
		
		Liquidacao l = new Liquidacao();
		Regular r = new Regular(0.95);
		
		b.setPromocao(r);
		b1.setPromocao(l);
		
		System.out.println(b.calcularPreco(r));
		System.out.println(b1.calcularPreco(l));
	}

}
