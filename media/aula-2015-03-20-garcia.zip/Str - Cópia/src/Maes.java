
public class Maes implements Promocao{

	@Override
	public double descontar() {
		return 0.86;
	}

}
