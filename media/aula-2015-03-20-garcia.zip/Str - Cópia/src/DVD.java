
public final class DVD extends Produto{

	public DVD(String nome, double preco) {
		super(nome, preco);
		// TODO Auto-generated constructor stub
	}



}
