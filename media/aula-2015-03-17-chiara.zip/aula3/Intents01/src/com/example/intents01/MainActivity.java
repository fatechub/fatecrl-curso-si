package com.example.intents01;

import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.app.Activity;
import android.content.Intent;

public class MainActivity extends Activity {
	Uri uri;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    
    public void sobreClick(View v){
    	Intent it = new Intent(this, MinhaIntentSobre.class);
    	startActivity(it);
    }
    public void webClick(View v){
    	Uri uri = Uri.parse("http://www.google.com");
    	Intent it2 = new Intent(Intent.ACTION_VIEW,uri);
    	startActivity(it2);
    }
    
}
