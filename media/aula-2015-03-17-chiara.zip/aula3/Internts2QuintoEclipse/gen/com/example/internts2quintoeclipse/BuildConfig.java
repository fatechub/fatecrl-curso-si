/** Automatically generated file. DO NOT MODIFY */
package com.example.internts2quintoeclipse;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}